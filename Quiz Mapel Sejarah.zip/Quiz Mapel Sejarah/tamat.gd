extends Node2D

func _ready() -> void:
	var nilai: int = ScoreManager.get_score() * 10
	$ScoreLabel.text = "Skor Akhir: %d / 100\n%s" % [nilai, get_predikat(nilai)]
	
func get_predikat(nilai: int) -> String:
	if nilai >= 90:
		return "Predikat: Sangat Baik"
	elif nilai >= 80:
		return "Predikat: Baik"
	elif nilai >= 70:
		return "Predikat: Cukup"
	elif nilai >= 60:
		return "Predikat: Perlu Ditingkatkan"
	return "Predikat: Belajar Lagi, Tetap Semangat!"

func _on_iya_pressed() -> void:
	ScoreManager.reset_score()
	get_tree().change_scene_to_file("res://pemilihan_level.tscn")

func _on_tidak_pressed() -> void:
	get_tree().quit()
