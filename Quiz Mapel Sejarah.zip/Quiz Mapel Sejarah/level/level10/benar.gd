extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_iya_pressed() -> void:
	get_tree().change_scene_to_file("res://tamat.tscn")


func _on_tidak_pressed() -> void:
	get_tree().change_scene_to_file("res://pemilihan_level.tscn")
