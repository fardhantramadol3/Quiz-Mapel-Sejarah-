extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_kembali_pressed() -> void:
	get_tree().change_scene_to_file("res://pemilihan_level.tscn")


func _on_a_pressed() -> void:
	ScoreManager.add_score()
	get_tree().change_scene_to_file("res://level/level10/soal.tscn")


func _on_b_pressed() -> void:
	get_tree().change_scene_to_file("res://level/level10/soal.tscn")


func _on_c_pressed() -> void:
	get_tree().change_scene_to_file("res://level/level10/soal.tscn")


func _on_d_pressed() -> void:
	get_tree().change_scene_to_file("res://level/level10/soal.tscn")
