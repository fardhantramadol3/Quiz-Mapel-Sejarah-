extends Node2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
func _on_kembali_pressed() -> void:
	get_tree().change_scene_to_file("res://menu.tscn")
	
func _on_level_1_pressed() -> void:
	get_tree().change_scene_to_file("res://level/level1/soal.tscn")
	
func _on_level_2_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_3_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_4_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_5_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_6_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_7_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_8_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_9_pressed() -> void:
	get_tree().change_scene_to_file("")

func _on_level_10_pressed() -> void:
	get_tree().change_scene_to_file("")
