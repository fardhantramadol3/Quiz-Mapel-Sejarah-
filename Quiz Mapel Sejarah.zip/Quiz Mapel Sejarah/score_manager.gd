extends Node

var score: int = 0

func add_score() -> void:
	score += 1

func get_score() -> int:
	return score

func reset_score() -> void:
	score = 0
